from django.apps import AppConfig


class FileUploadAppConfig(AppConfig):
    name = 'file_upload_app'
